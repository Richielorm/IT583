﻿using System;

public class Lab01
{
    public static void Main()
    {
        Console.WriteLine("CS 201 Restaurant Guide\n");//Console.WriteLine is used to print an output and then leave a line
        String response;
        char f;
        char s;
        bool fancy;
        bool spicy;
        Console.Write("Do you like spicy food?(y/n):");
        response = Console.ReadLine();//Console.ReadLine() is used to take input a string
        s = response[0];//Taking only the first character of the string
        if ((s == 'y') || (s == 'Y'))
            spicy = true;
        else
            spicy = false;

        Console.Write("Do you want to go to a fancy restaurant?(y/n):");
        response = Console.ReadLine();
        f = response[0];
        fancy = ((f == 'y') || (f == 'Y'));
        if (spicy)
        {     //First Block
            if (fancy)
                Console.WriteLine("I suggest you go to Thai Garden Palace.");
            else
                Console.WriteLine("I suggest you to go to Alberto's Tacqueria.");
        }
        else
        {     //Second Block
            if (fancy)
                Console.WriteLine("I suggest you to go to Chez Paris.");
            else
                Console.WriteLine("I suggest you go to Joe's Diner.");
        }
    }
}