﻿#include<iostream> // header files
using namespace std;
int main()
{ // main function
    int choice1, choice2, num, ch1, ch2; // variables to store choice
    while (1)
    { // to display menu again and again
        float cost = 0; // to store total cost
        cout << endl;
        cout << "------Welcome to EYE GLASS store------" << endl;
        cout << endl;
        cout << "1.Prescription glass price=$40" << endl;
        cout << "2.Non-Prescription sunglass price=$25" << endl;
        cout << "enter your choice:" << endl;
        cin >> choice1; // to take user choice
        cout << "No of pieces:" << endl;
        cin >> ch1; // to take no of pieces
        if (choice1 == 1)
        { // if choice 1
            cost = cost + (ch1 * 40);
            cout << "1.Anti-glare coating price=$12.50" << endl;
            cout << "2.Brown tint coating price=$9.99" << endl;
            cout << "enter your choice:" << endl;
            cin >> choice2; // asking for type of glasses
            if (choice2 == 1)
            { // if 1
                cost = cost + 12.50;
                cout << "total cost:" << cost << endl;
            }
            if (choice2 == 2)
            { // if 2
                cost = cost + 9.99;
                cout << "total cost:" << cost << endl;
            }
        }
        if (choice1 == 2)
        { // if choice 2
            cost = cost + (ch1 * 25);
            cout << "1.Anti-glare coating price=$12.50" << endl;
            cout << "2.Brown tint coating price=$9.99" << endl;
            cout << "enter your choice:" << endl;
            cin >> choice2; // asking for type of glasses
            if (choice2 == 1)
            { // if 1
                cost = cost + 12.50;
                cout << "total cost:" << cost << endl;
            }
            if (choice2 == 2)
            { // if 2
                cost = cost + 9.99;
                cout << "total cost:" << cost << endl;
            }
        }
        if (choice1 != 1 && choice1 != 2)
        { // if choice otherthan 1 and 2
            exit(0); // program exits
        }
    }

}
