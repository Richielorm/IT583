﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab04
{
    class Program
    {
        static void Main(string[] args)
        {
            int A = 1, B = 3, C = 5;
            double X = 2.2, Y = 4.4, Z = 6.6, Ans;

            Ans = Average(A, B);
            Console.WriteLine("\nAverage(A, B) = " + Ans);

            Ans = Average(A, B, C);
            Console.WriteLine("\nAverage(A, B, C) = " + Ans);

            Ans = Average(X, Y);
            Console.WriteLine("\nAverage(X, Y) = " + Ans);

            Ans = Average(X, Y, Z);
            Console.WriteLine("\nAverage(X, Y, Z) = " + Ans);

            // Just put here so app doesn't exit automatically
            Console.Read();
        }

        public static double Average(int n1, int n2)
        {
            return (n1 + n2) / 2.0;
        }

        public static double Average(int n1, int n2, int n3)
        {
            return (n1 + n2 + n3) / 3.0;
        }

        public static double Average(double n1, double n2)
        {
            return (n1 + n2) / 2.0;
        }

        public static double Average(double n1, double n2, double n3)
        {
            return (n1 + n2 + n3) / 3.0;
        }
    }
}
